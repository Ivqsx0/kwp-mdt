KWP MDT – darmowy hosting z API (24/7)
======================================

Netlify Drop = TYLKO pliki statyczne (bez API) → online między osobami NIE działa.
Potrzebujesz hostingu z backendem.

OPCJA 1: Render.com (zalecane, darmowe)
---------------------------------------
1. Załóż konto: https://render.com (login Google/GitHub)
2. Dashboard → New + → Web Service
3. "Deploy an existing image from registry?" → NIE
   Albo: podłącz GitHub z tym folderem
   Albo prostszy sposób poniżej (bez Git):

   SZYBKI SPOSÓB bez GitHuba:
   - Zainstaluj Render CLI albo użyj GitHub:
   a) Wrzuć folder "kwp-mdt-deploy" na GitHub (public repo)
   b) Render → New Web Service → połącz repo
   c) Runtime: Python
   d) Build Command: (puste lub: true)
   e) Start Command: python mdt_server.py
   f) Plan: Free
   g) Create Web Service

4. Po deployu dostaniesz link typu:
   https://kwp-mdt.onrender.com/MDT-Policja.html
5. TYM linkiem dzielisz się z kolegami (Chrome/Edge/Firefox/Opera).

Uwaga Render Free: po ~15 min bez ruchu może "zasnąć".
Pierwsze otwarcie po śnie trwa 30–60 s, potem działa normalnie.

OPCJA 2: Railway.app
--------------------
1. https://railway.app → login GitHub
2. New Project → Deploy from GitHub (to samo repo)
3. Start Command: python mdt_server.py
4. Generate Domain → link do MDT

OPCJA 3: Glitch.com
-------------------
1. https://glitch.com
2. New project → Import from GitHub / upload plików
3. W package może być trudniej z Python – lepiej Render.

Dlaczego to działa:
Serwer ma /api/sync (wspólna baza). Netlify Drop tego nie ma.
